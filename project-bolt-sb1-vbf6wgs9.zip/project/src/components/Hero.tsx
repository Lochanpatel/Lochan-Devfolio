import { Mail, MapPin, Linkedin, Github } from 'lucide-react';

function Hero() {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center pt-20 px-6"
    >
      <div className="container mx-auto max-w-6xl">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight">
              Lochan Patel
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Focused and adaptable developer with strong problem-solving and
              teamwork skills
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-gray-600">
            <a
              href="mailto:patellochan31@gmail.com"
              className="flex items-center gap-2 hover:text-blue-600 transition-colors"
            >
              <Mail size={20} />
              <span className="text-sm">patellochan31@gmail.com</span>
            </a>
            <div className="flex items-center gap-2">
              <MapPin size={20} />
              <span className="text-sm">Ratlam, MP</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4">
            <a
              href="https://linkedin.com/in/lochan-patel-49b9b3249"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-white rounded-full shadow-md hover:shadow-xl hover:scale-110 transition-all duration-300"
            >
              <Linkedin size={24} className="text-blue-600" />
            </a>
            <a
              href="https://github.com/lochanpatel"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 bg-white rounded-full shadow-md hover:shadow-xl hover:scale-110 transition-all duration-300"
            >
              <Github size={24} className="text-gray-900" />
            </a>
          </div>

          <div className="pt-8">
            <a
              href="#contact"
              className="inline-block px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-medium rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              Get In Touch
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
