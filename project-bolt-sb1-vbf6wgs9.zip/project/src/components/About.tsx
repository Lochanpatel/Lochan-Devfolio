import { User, Code, Brain } from 'lucide-react';

function About() {
  return (
    <section id="about" className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900">
          About Me
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
              <User className="text-blue-600" size={32} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-gray-900">
              Focused Developer
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Computer Science Engineering student specializing in Big Data
              Analytics with a passion for creating innovative web solutions.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-cyan-100 rounded-full flex items-center justify-center mb-6">
              <Code className="text-cyan-600" size={32} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-gray-900">
              Problem Solver
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Solved 400+ algorithmic problems on LeetCode with a rating of
              1626, demonstrating strong DSA expertise.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
              <Brain className="text-blue-600" size={32} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-gray-900">
              Team Player
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Strong teamwork and leadership skills with experience in
              collaborative development environments.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
