import { ExternalLink, Folder } from 'lucide-react';

function Projects() {
  const projects = [
    {
      title: 'DreamStay',
      subtitle: 'Real Estate Booking System',
      tech: ['React', 'JavaScript', 'HTML5', 'CSS3'],
      description: [
        'Implemented property search and multi-criteria filters (city, property type, price range) to enhance discovery and conversion.',
        'Designed responsive property cards (price, location, details) to improve UI/UX and user engagement.',
        'Ensured cross-device compatibility and performance through semantic HTML5, modular CSS3, and client-side optimizations.',
      ],
    },
    {
      title: 'DSA Fusion Hub',
      subtitle: 'Team Project',
      tech: ['React', 'Node.js', 'Express', 'MongoDB'],
      description: [
        'Developed a centralized DSA platform using React.js and MongoDB to organize and customize preparation sheets.',
        'Built reusable React components, client-side state management, and responsive UI to improve usability and retention.',
        'Implemented customizable sheets, filters, and progress tracking for personalized learning.',
        'Integrated Node.js/Express RESTful APIs enabling secure CRUD operations and reliable data storage.',
      ],
    },
  ];

  return (
    <section id="projects" className="py-20 px-6 bg-white/50">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900">
          Projects
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Folder className="text-blue-600" size={24} />
                </div>
                <ExternalLink
                  className="text-gray-400 hover:text-blue-600 transition-colors cursor-pointer"
                  size={20}
                />
              </div>

              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {project.title}
              </h3>
              <p className="text-sm text-blue-600 font-medium mb-4">
                {project.subtitle}
              </p>

              <div className="flex flex-wrap gap-2 mb-6">
                {project.tech.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className="px-3 py-1 bg-blue-50 text-blue-600 text-sm rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              <ul className="space-y-3 text-gray-600 text-sm">
                {project.description.map((desc, descIndex) => (
                  <li key={descIndex} className="flex gap-2">
                    <span className="text-blue-600 font-bold mt-1">•</span>
                    <span>{desc}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
