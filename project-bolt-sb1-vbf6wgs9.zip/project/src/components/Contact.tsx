import { Mail, MapPin, Linkedin, Github, Phone } from 'lucide-react';

function Contact() {
  return (
    <section id="contact" className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900">
          Get In Touch
        </h2>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl p-12 shadow-xl">
            <div className="text-center mb-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Let's Connect
              </h3>
              <p className="text-gray-600 leading-relaxed max-w-2xl mx-auto">
                I'm always interested in hearing about new opportunities,
                collaborations, or just having a chat about technology and
                development.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <a
                href="mailto:patellochan31@gmail.com"
                className="flex items-center gap-4 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Mail className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Email</p>
                  <p className="text-gray-900 font-medium">
                    patellochan31@gmail.com
                  </p>
                </div>
              </a>

              <a
                href="tel:+917566039795"
                className="flex items-center gap-4 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Phone</p>
                  <p className="text-gray-900 font-medium">+91 7566039795</p>
                </div>
              </a>

              <div className="flex items-center gap-4 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Location</p>
                  <p className="text-gray-900 font-medium">Ratlam, MP</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                <div className="flex gap-3">
                  <a
                    href="https://linkedin.com/in/lochan-patel-49b9b3249"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  >
                    <Linkedin className="text-white" size={24} />
                  </a>
                  <a
                    href="https://github.com/lochanpatel"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-gray-900 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  >
                    <Github className="text-white" size={24} />
                  </a>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Social</p>
                  <p className="text-gray-900 font-medium">
                    LinkedIn & GitHub
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Contact;
