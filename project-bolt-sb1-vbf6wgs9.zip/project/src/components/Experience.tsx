import { Briefcase, Calendar } from 'lucide-react';

function Experience() {
  return (
    <section id="experience" className="py-20 px-6 bg-white/50">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900">
          Work Experience
        </h2>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow border-l-4 border-blue-600">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  Web Development Intern
                </h3>
                <div className="flex items-center gap-2 text-blue-600 font-medium">
                  <Briefcase size={20} />
                  <span>Where U Elevate</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-gray-600 mt-4 md:mt-0">
                <Calendar size={20} />
                <span>May 2025 - July 2025</span>
              </div>
            </div>

            <ul className="space-y-4 text-gray-600">
              <li className="flex gap-3">
                <span className="text-blue-600 font-bold mt-1">•</span>
                <span>
                  Built responsive web pages using HTML, CSS, JavaScript, and
                  React.js.
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-600 font-bold mt-1">•</span>
                <span>
                  Improved UI/UX and performance, enhancing load speed by 25%.
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-blue-600 font-bold mt-1">•</span>
                <span>
                  Assisted in testing, debugging, and deployment of front-end
                  features for production.
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Experience;
