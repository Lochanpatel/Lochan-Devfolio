import { Code2, Wrench, Database, Users } from 'lucide-react';

function Skills() {
  const skillCategories = [
    {
      icon: Code2,
      title: 'Programming Languages',
      skills: ['C', 'C++', 'HTML5', 'CSS3', 'JavaScript (ES6+)', 'SQL'],
    },
    {
      icon: Wrench,
      title: 'Frameworks & Tools',
      skills: [
        'React.js',
        'Vue.js',
        'Git',
        'GitHub',
        'REST APIs',
        'JSON',
        'Linux',
      ],
    },
    {
      icon: Database,
      title: 'Databases & Platforms',
      skills: [
        'MongoDB',
        'MySQL',
        'MySQL Workbench',
        'Visual Studio Code',
        'IBM Cognos Analytics',
      ],
    },
    {
      icon: Users,
      title: 'Soft Skills',
      skills: [
        'Team Leadership',
        'Decision-Making',
        'Critical Thinking',
        'Adaptability',
        'Flexibility',
        'Analytical Thinking',
      ],
    },
  ];

  return (
    <section id="skills" className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900">
          Skills
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Icon className="text-blue-600" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                    {category.title}
                  </h3>
                </div>

                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <span
                      key={skillIndex}
                      className="px-4 py-2 bg-gradient-to-r from-blue-50 to-cyan-50 text-gray-700 text-sm rounded-lg hover:shadow-md transition-shadow"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default Skills;
